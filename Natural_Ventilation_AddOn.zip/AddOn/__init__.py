# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Natural_Ventilation",
    "author" : "Carlos Dias",
    "description" : "",
    "blender" : (2, 80, 0),
    "version" : (0, 0, 1),
    "location" : "",
    "warning" : "",
    "category" : "Generic"
}

import ifcopenshell
import ifctester.ids as ids

import bonsai.tool as tool
import requests
from bpy.props import *
from bpy.utils import register_class, unregister_class

from bpy.types import Scene
from bpy.types import Panel
from bpy.types import Operator
from bpy.types import PropertyGroup
import bpy

###########################################################
## functions
############################################################
# get windows 
def get_windows(context):
    objs = context.selected_objects
    windows = []
    if len(objs) > 0:
        obj = objs[0]
        id = obj.BIMObjectProperties.ifc_definition_id
        model = tool.Ifc.get()
        space = model.by_id(id)        
        if space.is_a() == 'IfcSpace':
            boundeds = space.BoundedBy            
            if len(boundeds) > 0:
                windows = [x.RelatedBuildingElement for x in boundeds if x.RelatedBuildingElement.is_a() == 'IfcWindow']
    return windows, space

# create IDS file
def create_ids(context):
    props = context.scene.my_props
    my_ids = ids.Ids(title = props.ids_title, author=props.ids_author)      
    
    apiurl = 'https://api.bsdd.buildingsmart.org/api/Class/v1'    
    
    uri = 'https://identifier.buildingsmart.org/uri/Labeee/Natural_Ventilation/1/class/3E.20.04.00.00.00.00'
    parameters = {'Uri' : uri, 'IncludeChildClassReferences' : True}
    
    uri2 = 'https://identifier.buildingsmart.org/uri/Labeee/Natural_Ventilation/1/class/4A.07.08.00.00.00.00'
    parameters2 = {'Uri' : uri2, 'IncludeChildClassReferences' : True}
    
    l = []
    print('searching in bSDD...')
    response = requests.get(apiurl, parameters)   
    response2 = requests.get(apiurl, parameters2)

    if response.status_code == 200:
        elements = response.json()['childClassReferences']
        # se ele encontrou as classes de espaços
        if response2.status_code == 200:
            spaces = response2.json()['childClassReferences']
            elements = elements + spaces

        for element in elements:
            uri_elem = element['uri']
            parameters = {'Uri' : uri_elem, 'IncludeClassProperties' : True}

            print(f'searching {element["code"]} - {element["name"]} in bSDD...')
            response2 = requests.get(apiurl, parameters)   
            print(f'Status code: {response2.status_code}')
                
            if response2.status_code == 200:
                resp = response2.json()
                print('OK')
                if 'classProperties' in resp:   
                    ifc_class = resp['relatedIfcEntityNames'][0]  
                    classification = ids.Classification(system = 'ABNT 15965',
                                                        value  = resp['code'],
                                                        uri    = uri_elem)   
                    entity = ids.Entity( name = ifc_class)

                    spec = ids.Specification(name=f"Ventilation properties for {resp['code']}-{resp['name']}", ifcVersion="IFC4")                   
                    spec.applicability.append(entity)
                    spec.applicability.append(classification)

                    for propclass in resp['classProperties']:
                        prop = propclass['propertyCode']
                        psetname = propclass['propertySet']
                        # if ifc_class == 'IfcSpace' and props.my_enum in ['ST', 'CR'] and  prop in [
                        #     'Single Sided Wind Pressure Coefficient Alhorithm',
                        #     'Facade Width'
                        #     ]:
                        #     pass
                            
                        #else:
                        ids_value = None
                        if 'allowedValues' in propclass:  
                            if propclass['dataType'] == 'Real':
                                datatype = 'IfcReal'
                                propvalue = float(propclass['allowedValues'][0]['value'])  
                            else:
                                datatype = 'IfcText'
                                propvalue = propclass['allowedValues'][0]['value']                            
                            ids_value=propvalue
                            all = True
                        else:
                            
                            if propclass['dataType'] == 'Real':
                                datatype = 'IfcReal'                             
                            else:
                                datatype = 'IfcText'
                            ids_value=None    
                            all = False                  
                        
                        print(f'   {psetname} -> {prop} -> {ids_value} -> {all}')

                        if psetname == 'Attributes':
                            ids_property = ids.Attribute(name=prop, value=ids_value)
                        else:
                            ids_property = ids.Property( uri=propclass['uri'],
                                                        baseName=prop,
                                                        propertySet=psetname,
                                                        dataType=datatype, 
                                                        value=ids_value
                            )                                    
                        spec.requirements.append(ids_property)

                        if not element['code'] in l:
                            my_ids.specifications.append(spec)
                            l.append(element['code'])
                            
                else:
                    print(f'{element["code"]} have no properties')
                        
            else:
                print(f'{element["code"]} not found')
        return my_ids
    else:
        return None
# add properties to enviroments windows 
def add_prop(context, windows, entity):
    model = tool.Ifc.get()
    props = context.scene.my_props
    props.id = f'Windows found: {str(len(windows))}'     
    entity = ids.Entity(name=entity)
    elements = windows
    classification = ifcopenshell.api.classification.add_classification(model, classification="ABNT 15965 4A")

    space_class = {
        'SS' : ['4A.07.08.02.00.00.00', 'Space Single-sided ventilatilation'],
        'CR' : ['4A.07.08.04.00.00.00', 'Space Cross ventilation'],
        'ST' : ['4A.07.08.06.00.00.00', 'Space Stack ventilation']
    }

    uri = 'https://identifier.buildingsmart.org/uri/Labeee/Natural_Ventilation/1/class'
    apiurl = 'https://api.bsdd.buildingsmart.org/api/Class/v1'    
    parameters = {'Uri' : '', 'IncludeClassProperties' : True}
    l = []

    print(100*'-')

    for element in elements:
        reference = ifcopenshell.util.classification.get_references(element)
        print(f'@@@@@@@ {reference}')
        if len(reference)>0 or element.is_a() == 'IfcSpace':
            
            if element.is_a() == 'IfcSpace':
                identification = space_class[props.my_enum][0]
                id_description = space_class[props.my_enum][1]   
            
                reference = ifcopenshell.api.classification.add_reference(model,
                    products=[element],
                    classification=classification,
                    identification=identification,
                    name= id_description)

            else:
                identification = reference.pop().Identification

            parameters['Uri'] = f'{uri}/{identification}'
            print('searching in bSDD...')
            response = requests.get(apiurl, parameters)   
            print(f'Status code: {response.status_code}')
            
            if response.status_code == 200:
                resp = response.json()
                
                print(resp['name'])

                if 'classProperties' in resp:     
                    for propclass in resp['classProperties']:
                        prop     = propclass['propertyCode']
                        psetname = propclass['propertySet']

                        # if element.is_a() == 'IfcSpace' and props.my_enum in ['ST', 'CR'] and  prop in [
                        #     'Single Sided Wind Pressure Coefficient Alhorithm',
                        #     'Facade Width'
                        #     ]:
                        #     pass                        
                        #else:                        

                        if 'allowedValues' in propclass:  
                            if propclass['dataType'] == 'Real':
                                datatype = 'IfcReal'
                                propvalue = float(propclass['allowedValues'][0]['value'])  

                            else:
                                datatype = 'IfcText'
                                propvalue = propclass['allowedValues'][0]['value']                           
                            prop_value = model.create_entity(datatype, wrappedValue=propvalue)    
                            all = True
                        else:
                            
                            if propclass['dataType'] == 'Real':
                                datatype = 'IfcReal'   
                                propvalue = 0                                     
                            else:
                                datatype = 'IfcText'
                                propvalue=' '  
                            prop_value = model.create_entity(datatype, wrappedValue=propvalue) 
                            all = False                  
                        
                        print(f'{psetname} -> {prop} -> {prop_value} -> {all}')

                        if(prop != 'Name'):
                            pset=ifcopenshell.api.run("pset.add_pset", model, product=element, name=psetname)
                            ifcopenshell.api.run("pset.edit_pset", model, pset=pset, properties={prop : prop_value})


                else:
                    print(f'{identification} have no properties')
                    
            else:
                print(f'{identification} not found')
                

###########################################################
## properties class
############################################################

# get items to enumeration propertiy
def get_items(self, context):
    return [
        ('SS', 'Single-sided', 'Single-side Ventilation'),
        ('CR', 'Cross', 'Cross Ventilation'),
        ('ST', 'Stack', 'stack Ventilation')
    ]                


class MyProperties(PropertyGroup):
    id         : StringProperty(name="id", default="")
    ids_author : StringProperty(name="ids author", default="liegegarlet@gmail.com")
    ids_title  : StringProperty(name="ids title", default="IFC Verification")
    report     : BoolProperty(name="", default=False)
    my_enum    : EnumProperty(name='Ventilation Type', description='Ventilation types', items=get_items)


###########################################################
## Panel classes
############################################################
# main panel
class Panel_Vent(Panel):
    bl_label        = "Airflow network properties from bSDD"
    bl_idname       = "VIEW3D_PT_vent"
    bl_space_type   = 'VIEW_3D'
    bl_region_type  = 'UI'
    bl_context      = "objectmode"
    bl_category     = "Natural_Ventilation"


    def draw(self, context):
        props = context.scene.my_props
        layout = self.layout        
        if len(context.selected_objects) > 0:
            layout.prop(props, "my_enum")
            windows, space = get_windows(context)            
            layout.label(text= f'Windows found: {len(windows)}') 
            row = layout.row(align=True)
            row.operator(Operator_Vent.bl_idname, text='Add Properties', icon='PLUS') 

# export ids panel        
class Panel_Ids(Panel):
    bl_label        = "IDS"
    bl_idname       = "VIEW3D_PT_ids"
    bl_space_type   = 'VIEW_3D'
    bl_region_type  = 'UI'
    bl_context      = "objectmode"
    bl_category     = "Natural_Ventilation"


    def draw(self, context):
        props = context.scene.my_props
        layout = self.layout    
        layout.label(text="Export IDS from bSDD")      
        row = layout.row(align=True)
        row.prop(props, 'ids_author')    
        row = layout.row(align=True)
        row.prop(props, 'ids_title') 
        row = layout.row(align=True)
        row.operator(Operator_Ids.bl_idname, text='Export IDS file', icon='EXPORT') 


###########################################################
## Operation classes
############################################################

class Operator_Vent(Operator):
    bl_idname = "cd.operator_mat"
    bl_label = "Add Prop"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):        
        windows, space = get_windows(context)
        props = context.scene.my_props
        print(windows)
        if len(windows) > 0:            
            add_prop(context, windows, "IFCWINDOW")
            add_prop(context, [space], "IFCSPACE")                        
        return {"FINISHED"}

class Operator_Ids(Operator):
    bl_idname = "cd.operator_ids"
    bl_label = "export ids"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context): 
        my_ids = create_ids(context)
        if my_ids is not None:
            
            file_path = tool.Ifc.get_path().replace('ifc', 'ids')
            #file_path = '/home/carlos-dias/Documentos/PROJETOS/LIÉGE/VENT/AddOn/teste.ids'
            result = my_ids.to_xml(file_path)
            if result:
                self.report({"INFO"}, "IDS file has been sucessfully saved!")
                print('IDS file has been sucessfully saved!')
            else:
                print('An error occurred while writing the IDS file!')
                        
        return {"FINISHED"}

###########################################################
## Class register
############################################################
classes = [
    Panel_Vent,
    Panel_Ids,
    Operator_Vent,
    Operator_Ids,
    MyProperties,    
]


def register():
    for cls in classes:
        register_class(cls)
    Scene.my_props = PointerProperty(type=MyProperties)

def unregister():
    del Scene.my_props
    for cls in classes:
        unregister_class(cls)